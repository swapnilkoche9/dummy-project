import React from 'react'
import Enzyme from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import ShipmentFiltersArea from '../../components/ShipmentFiltersArea'

Enzyme.configure({ adapter: new Adapter() })
const { shallow } = Enzyme

const getShipmentSearchParam = jest.fn()
const getFilteredShipmentList = jest.fn()
const wrapper = shallow(
  <ShipmentFiltersArea
    getShipmentSearchParam ={getShipmentSearchParam}
    getFilteredShipmentList={getFilteredShipmentList}
  />
)
test('should render ShipmentFiltersArea correctly', () => {
  expect(wrapper).toMatchSnapshot()
})

test('should render ShipmentFiltersArea with alt data correctly', () => {
  wrapper.setProps({
    totalPageCount: 5
  })
  expect(wrapper).toMatchSnapshot()
})
