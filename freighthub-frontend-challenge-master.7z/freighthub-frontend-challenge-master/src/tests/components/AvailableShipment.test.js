import React from 'react'
import Enzyme from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import AvailableShipment from '../../components/AvailableShipment'

Enzyme.configure({ adapter: new Adapter() })
const { shallow } = Enzyme

const getPageParams = jest.fn()
const wrapper = shallow(
  <AvailableShipment
    key={1}
    name={'shipment'}
    userId={'U1001'}
    id={'S1001'}
    mode={''}
    destination={'germany'}
    origin={'india'}
    status={'Active'}
  />
)
test('should render AvailableShipment correctly', () => {
  expect(wrapper).toMatchSnapshot()
})

test('should render AvailableShipment with alt data correctly', () => {
  wrapper.setProps({
    color: 'black'
  })
  expect(wrapper).toMatchSnapshot()
})
