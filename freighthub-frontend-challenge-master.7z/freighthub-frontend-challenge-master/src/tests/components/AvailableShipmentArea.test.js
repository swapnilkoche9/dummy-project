import React from 'react'
import Enzyme from 'enzyme'
import Adapter from 'enzyme-adapter-react-16'
import AvailableShipmentArea from '../../components/AvailableShipmentArea'

Enzyme.configure({ adapter: new Adapter() })
const { shallow } = Enzyme

const getPageParams = jest.fn()
const getSortFilterParams = jest.fn()
const changePageNumber =jest.fn()
const wrapper = shallow(
  <AvailableShipmentArea
    getPageParams={getPageParams}
    getSortByFilterParams={getSortFilterParams}
    changePageNumber={changePageNumber}
    totalShipmentsCount={10}
    totalPageCount={3}
    currentPage={1}
    filteredShipmentList={[{
      
    }]}
    shipments={[{
      
    }]}
    
    totalPageCount={100}

  />
)
test('should render AvailableShipmentArea correctly', () => {
  expect(wrapper).toMatchSnapshot()
})

test('should render AvailableShipmentArea with alt data correctly', () => {
  wrapper.setProps({
    color: 'block'
  })
  expect(wrapper).toMatchSnapshot()
})
