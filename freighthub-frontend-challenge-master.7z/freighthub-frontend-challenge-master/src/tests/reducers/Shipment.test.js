import ShipmentReducer from '../../reducers/Shipment'

test('should setup default shipments values', () => {
  const state = ShipmentReducer(undefined, { type: '@@INIT' })
  expect(state).toEqual({
    shipments: [],
    totalShipmentsCount: 0
  })
})

test('should successfully fetch all shipments', () => {
  const state = ShipmentReducer(undefined, {
    type: 'FETCH_ALL_SHIPMENT_SUCCEEDED',
    payload: { shipments: ['mercedes'] }
  })
  expect(state.shipments).toEqual({"shipments": ["mercedes"]})
})

test('should return error on failure to fetch shipments', () => {
  const state = ShipmentReducer(undefined, {
    type: 'FETCH_ALL_SHIPMENT_FAILED',
    payload: {
      error: {
        message: 'error'
      }
    }
  })
  expect(state.shipments.error).toEqual(undefined)
})


