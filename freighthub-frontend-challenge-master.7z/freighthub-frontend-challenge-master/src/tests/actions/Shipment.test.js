import * as configureMockStore from 'redux-mock-store'
import thunk from 'redux-thunk'

import {
  getAllShipments,
  getShipmentsFailure,
  getShipmentsSuccess,
  
} from '../../actions/Shipments'

import * as types from '../../constants'

const middlewares = [thunk]
const mockStore = configureMockStore.default(middlewares)

let store = {}
const localStorageMock = {
  getItem: jest.fn().mockImplementation((key) => {
    return store[key] || null
  }),
  setItem: jest.fn((key, value) => {
    store[key] = value
  }),
  clear: jest.fn().mockImplementation(() => {
    store = {}
  }),
  removeItem: jest.fn().mockImplementation((key) => {
    delete store[key]
  })
}
window.localStorage = localStorageMock

window.localStorage.setItem('shipment', JSON.stringify([{ Name: 'shipment' }]))

beforeEach(() => {
  const shipments = JSON.stringify({ Name: 'shipment' })
  window.fetch = jest.fn().mockImplementation(() => {
    return new Promise((resolve, reject) => {
      resolve({
        status: 200,
        json: () => shipments
      })
    })
  })
})

test('should successfully get Shipment', () => {
  const action = getShipmentsSuccess(['jeep'])
  expect(action.type).toEqual('FETCH_ALL_SHIPMENT_SUCCEEDED')
  expect(action.payload).toEqual(['jeep'])
})



test('should get all Shipment', () => {

  const expectedActions = [
    { type: types.FETCH_ALL_SHIPMENT_SUCCEEDED, payload: { Shipment: [{ Name: 'car' }] } },
    { type: types.FETCH_ALL_SHIPMENT_FAILED }
  ]
  const store = mockStore({ Shipment: [] })
  return store.dispatch(getAllShipments()).then(() => {
    // return of async actions
    expect(store.getActions()[0].type).toEqual('FETCH_ALL_SHIPMENT_SUCCEEDED')
  })
})


