import {
  FETCH_ALL_SHIPMENT_SUCCEEDED,
  FETCH_ALL_SHIPMENT_FAILED,
  UPDATE_SHIPMENT_NAME_SUCCEEDED
} from '../constants'

import { getShipmentApi} from '../utils/Shipment'
import { handleError } from '../utils/fetch'
import { Dispatch } from 'react';




export function getShipmentsSuccess(data: any) {
  return {
    type: FETCH_ALL_SHIPMENT_SUCCEEDED,
    payload: data
  }
}

export function getShipmentsFailure(error: string) {
  return {
    type: FETCH_ALL_SHIPMENT_FAILED,
    payload: {
      error: error
    }
  }
}
export function updateShipmentNameSuccess(data: any) {
  return {
    type: UPDATE_SHIPMENT_NAME_SUCCEEDED,
    payload: data
  }
}


export function getAllShipments(params: any) {
  return (dispatch: Dispatch<any>) => {
    return getShipmentApi(params)
      .then((response) => {
        dispatch(getShipmentsSuccess(response))
        return true
      })
      .catch((error) => {
        dispatch(getShipmentsFailure(handleError(error)))
        return false
      })
  }
}


export function updateShipmentName(params: string, id:string ,shipments:any) {
  return (dispatch: Dispatch<any>) => {
      shipments.forEach((shipment:any)=> {
        if (shipment.id === id) {
           shipment.name=params
        }
    });

        dispatch(updateShipmentNameSuccess(shipments))
      
  }
}



