import React from 'react'

const SearchBox = (props: any) => {
  const {
    getFilterParams
  } = props
  return (<div>
   <input className={'searchInput'} type="text" placeholder="Search Shipment" onChange={getFilterParams}/>
  </div>
  )
}

export default SearchBox
