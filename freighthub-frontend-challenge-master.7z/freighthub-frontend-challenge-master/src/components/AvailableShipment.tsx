import React from 'react'
import { Link } from 'react-router-dom'
import constants from '../constants/SystemConstants'
import { AvailableShipmentProps } from '../utils/interface'
const AvailableShipment = (props: AvailableShipmentProps) => (
  <div className='availableShipment'>
    <div className='availableShipmentDetails'>
      <div className={'shipmentEntryDetail'}>
        <div>
          <p className='availableShipmentstext availableShipmentsTextSmall shipmentEntryLabel'>{'Shipment Id :'}</p>
        </div>
        <div>
          <p className='availableShipmentstext availableShipmentsTextBold'>{`${props.id}`}</p>
        </div>
      </div>
      <div className={'shipmentEntryDetail'}>
        <div>
          <p className='availableShipmentstext availableShipmentsTextSmall shipmentEntryLabel'>{'Shipment Name :'}</p>
        </div>
        <div>
          <p className='availableShipmentstext availableShipmentsTextSmall'>{`${props.name}`}</p>
        </div>
      </div>
      <div className="viewDetailsLinkContainer">
        <Link to={`/shipment/${props.id}`} className='availableShipmentstext availableShipmentsTextSmall linkTextOange'>{constants.VIEW_DETAILS_TEXT}</Link>
      </div>
    </div>
  </div>
)

export default AvailableShipment
