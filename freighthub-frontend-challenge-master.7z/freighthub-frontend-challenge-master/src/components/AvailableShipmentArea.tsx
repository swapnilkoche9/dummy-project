import React from 'react'
import constants from '../constants/SystemConstants'
import { AvailableShipmentAreaProps, Shipment, Shipments } from '../utils/interface'
import { Suspense, lazy } from 'react';

const AvailableShipment = lazy(() => import('./AvailableShipment'));
const Pagination = lazy(() => import('./Pagination'));
const Dropdown = lazy(() => import('./Dropdown'));
const sort_UserId_DropDownContent = [constants.ASC_SORT_ORDER_USERID, constants.DES_SORT_ORDER_USERID,constants.ASC_SORT_ORDER_SHIPMENTID, constants.DES_SORT_ORDER_SHIPMENTID]

let renderAvailableShipments = (shipments: Shipments) => {
  return shipments && shipments.map((shipment: Shipment, index: number) => {
    const {
      name,
      userId,
      id,
      mode,
      destination,
      origin,
      status
    } = shipment
    return (
      <Suspense fallback={<div />} key={index}>
        <AvailableShipment
          key={index}
          name={name}
          userId={userId}
          id={id}
          mode={mode}
          destination={destination}
          origin={origin}
          status={status}
        />
      </Suspense>
    )
  })
}

const AvailableShipmentArea = (props: AvailableShipmentAreaProps) => {
  const {
    shipments,
    totalShipmentsCount,
    totalPageCount,
    getSortByFilterParams,
    getPageParams,
    changePageNumber,
    currentPage,
    filteredShipmentList
  } = props
  return (
    <div className='availableShipmentsContainer'>
      <div className="availableTextAndSortContainer">
        <div className="availableTextAndResultContainer">
          <div className="availableTextContainer">
            <p className='availableText'>{constants.AVAILABLE_SHIPMENT_TEXT}</p>
          </div>
          <div className="resultTextContainer">
            <p className='resultText'>{`${constants.SHOWING_TEXT} ${ shipments && shipments.length} ${constants.OF_TEXT} ${totalShipmentsCount} ${constants.RESULT_TEXT}`}</p>
          </div>
        </div>
        <div className="sortDropDownContainer">
          <Suspense fallback={<div />}>
            <Dropdown
              dropdownContent={sort_UserId_DropDownContent}
              getFilterParams={getSortByFilterParams}
              dropDownLabel={constants.SORT_BY_TEXT}
            />
          </Suspense>
        </div>
      </div>
      {renderAvailableShipments(shipments)}
      <Suspense fallback={<div />}>
        {filteredShipmentList.length >= 10 || currentPage === totalPageCount ?<Pagination
          getPageParams={getPageParams}
          totalPageCount={totalPageCount}
          currentPage={currentPage}
          changePageNumber={changePageNumber}
        />:<div/>}
      </Suspense>
    </div>
  )
}

export default AvailableShipmentArea
