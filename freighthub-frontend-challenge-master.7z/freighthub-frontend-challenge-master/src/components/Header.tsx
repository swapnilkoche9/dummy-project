import React from 'react'
import logo from '../assets/logo.png'
import constants from '../constants/SystemConstants'

const Header = () => (
  <div className='header'>
    <div className='headerLeft'>
      <img className='headerLogo' src={logo} alt={'shipment Company Image'} />
    </div>
    <div className='headerRight'>
      <a href='#myShipment' className='headerLink'>{constants.MY_SHIPMENT}</a>
      <a href='#trackShipment' className='headerLink'>{constants.TRACK_SHIPMENT}</a>
    </div>
  </div>
)

export default Header
