import React from 'react'
import constants from '../constants/SystemConstants'
import { ShipmentFiltersAreaProps } from '../utils/interface'
import { Suspense, lazy } from 'react';

const SearchBox = lazy(() => import('./SearchBox'));
const Button = lazy(() => import('./Button'));

const ShipmentFiltersArea = (props: ShipmentFiltersAreaProps) => {
  const {
    getShipmentSearchParam,
    getFilteredShipmentList
  } = props

  return (
    <div className='filtersContainer'>
      <div className='filtersContainerContent'>
        <div className='filterDropdown'>
          <Suspense fallback={<div />}>
            <SearchBox
              getFilterParams={getShipmentSearchParam}
            />
          </Suspense>
        </div>
        <div className='filterBtnContainer'>
          <Suspense fallback={<div />}>
            <Button handleClick={getFilteredShipmentList} text={constants.BUTTON_TEXT} />
          </Suspense>
        </div>
      </div>
    </div>
  )
}

export default ShipmentFiltersArea
