const systemConstants = {
    ASC_SORT_ORDER_USERID: 'User Id Ascending',
    DES_SORT_ORDER_USERID: 'User Id Descending',
    ASC_SORT_ORDER_SHIPMENTID: 'Shipment Id Ascending',
    DES_SORT_ORDER_SHIPMENTID: 'Shipment Id Descending',
    USER_INITIAL: 'U',
    SHIPMENT_INITIAL: 'S',
    BUTTON_TEXT: 'Search',
    SORT_BY_TEXT: 'Sort by',
    AVAILABLE_SHIPMENT_TEXT: 'Available Shipments',
    VIEW_DETAILS_TEXT: 'View details',
    FOOTER_TEXT: '© Shipment Group 2019',
    MY_SHIPMENT: 'My Shipment',
    TRACK_SHIPMENT: 'Track Shipment',
    SHIPMENT_DATA: [{}, {}, {}, {}, {}],
    ORANGE_COLOR: '#EA7F28',
    DARK_GRAY_COLOR: '#4A4A4A',
    WHITE_COLOR: 'white',

    NOT_FOUND_TEXT: '404 - Not Found',
    PAGE_NOT_EXIST: 'Sorry, the page you are looking for does not exist.',
    GO_BACK_TEXT: 'You can always go back to the',
    HOMEPAGE_TEXT: 'homepage',
    SHOWING_TEXT: 'Showing',
    OF_TEXT: 'of',
    RESULT_TEXT: 'results',
    FIRST: 'First',
    PREVIOUS: 'Previous',
    NEXT: 'Next',
    LAST: 'Last',
    PAGE_TEXT: 'Page',
    SHIPMENT_PER_PAGE:20,
    NOT_FOUND:'Shipment Details Not Found'


    

};
export default systemConstants;
