import React, { Fragment } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as shipmentsActions from '../actions/Shipments'
import { ShipmentDetailsProps, ShipmentDetailsState, Shipment } from '../utils/interface'
import constants from '../constants/SystemConstants'

class ShipmentDetails extends React.Component<ShipmentDetailsProps, ShipmentDetailsState> {

  constructor(props: ShipmentDetailsProps) {
    super(props)
    this.state = {
      selectedShipment: [],
      isNameEditable: false,
      newShipmentName: ''

    }
  }
  componentDidMount() {
    this.props.shipmentsActions.getAllShipments().then(() => {
      this.getSelectedShipment()
    })

  }
  getSelectedShipment = () => {
    let selectedShipment = this.props.shipments && this.props.shipments.filter((shipment: Shipment) => shipment.id === this.props.match.params.shipmentId)
    this.setState({ selectedShipment: selectedShipment })
  }

  handleNameEdit = () => {
    this.setState({ isNameEditable: true })
  }
  getNewShipmentNAme = (input: any) => {
    this.setState({ newShipmentName: input.target.value })
  }
  handleNameSave = () => {
    let selectedShipment = this.state.selectedShipment[0]
    selectedShipment.name = this.state.newShipmentName
    var data = selectedShipment
    var json = JSON.stringify(data);
    var xhr = new XMLHttpRequest();
    xhr.open("PUT", 'http://localhost:3000/shipments/' + this.state.selectedShipment[0].id, true);
    xhr.setRequestHeader('Content-type', 'application/json; charset=utf-8');
    xhr.send(json);
    this.setState({ isNameEditable: false })
  }

  render() {
    return (
      <Fragment>
        {this.state.selectedShipment.length > 0 ? <div className="shipmentDescriptionContainer">
          <div className="shipmentTextEntry">
            <div className="shipmentDescription shipmentEntryLabel">{'Name :'}</div>
            {!this.state.isNameEditable ? <div className="shipmentDescription">{this.state.selectedShipment[0].name}
              <a role="button" className="editButton" title="Edit" onClick={this.handleNameEdit}>✏️</a></div> :
              <div><input type="text" onChange={this.getNewShipmentNAme} />  <a role="button" className="saveButton" title="Save" onClick={this.handleNameSave}>save</a></div>}
          </div>
          <div className="shipmentTextEntry">
            <div className="shipmentDescription shipmentEntryLabel">{'Origin :'}</div>
            <div className="shipmentDescription">{this.state.selectedShipment[0].origin}</div>
          </div>
          <div className="shipmentTextEntry">
            <div className="shipmentDescription shipmentEntryLabel">{'Destination :'}</div>
            <div className="shipmentDescription">{this.state.selectedShipment[0].destination}</div>
          </div>
          <div className="shipmentTextEntry">
            <div className="shipmentDescription shipmentEntryLabel">{'User Id :'}</div>
            <div className="shipmentDescription">{this.state.selectedShipment[0].userId}</div>
          </div>
          <div className="shipmentTextEntry">
            <div className="shipmentDescription shipmentEntryLabel">{'Status :'}</div>
            <div className="shipmentDescription">{this.state.selectedShipment[0].status}</div>
          </div>
          <div className="shipmentTextEntry">
            <div className="shipmentDescription shipmentEntryLabel">{'Total :'}</div>
            <div className="shipmentDescription">{this.state.selectedShipment[0].total}</div>
          </div>
        </div> : <div className="shipmentNotFound">{constants.NOT_FOUND}</div>}
      </Fragment>
    )
  }
}

const mapStateToProps = (state: ShipmentDetailsProps) => {
  return {
    shipments: state.Shipment.shipments
  }
}

const mapDispatchToProps = (dispatch: any) => {
  return {
    shipmentsActions: bindActionCreators(shipmentsActions, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ShipmentDetails)
