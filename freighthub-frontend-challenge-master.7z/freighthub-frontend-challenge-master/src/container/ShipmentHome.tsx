import React from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import * as shipmentsActions from '../actions/Shipments'
import constants from '../constants/SystemConstants'
import { ShipmentHomeProps, ShipmentHomeState, FilterObject } from '../utils/interface'
import { Suspense, lazy } from 'react';

const AvailableShipmentArea = lazy(() => import('../components/AvailableShipmentArea'));
const ShipmentFiltersArea = lazy(() => import('../components/ShipmentFiltersArea'));
const Loading = lazy(() => import('../components/Loading'));

class ShipmentHome extends React.Component<ShipmentHomeProps, ShipmentHomeState>{
  constructor(props: ShipmentHomeProps) {
    super(props)
    this.state = {
      shipmentDataFetchingDone: false,
      shipmentId: '',
      SortingValue: '',
      filteredShipmentList: [],
      selectedPage: 1,
      totalPageCount: 0
    }
  }

  componentDidMount() {
    this.props.shipmentsActions.getAllShipments().then(() => {

      this.setState({ filteredShipmentList: this.props.shipments.slice(0, 20), shipmentDataFetchingDone: true })
    })
  }

  getPageParams = (page: number) => {
    //  this.setState({ filteredShipmentList: this.state.filteredShipmentList.length >= 20 ? this.props.shipments.slice(20*page-20, 20*page): this.state.filteredShipmentList })
    this.setState({ filteredShipmentList: true ? this.props.shipments.slice(20 * page - 20, 20 * page) : this.state.filteredShipmentList })
    //this.setState({ filteredShipmentList: this.props.shipments.slice(20,24)})
  }
  changePageNumber = (page: number) => {

    if (this.state.filteredShipmentList.length <= 20 || page === Math.ceil(this.props.shipments.length / constants.SHIPMENT_PER_PAGE))
      this.setState({ selectedPage: page })
  }
  getSortByFilterParams = (sortingValue: FilterObject) => {
    this.setState({ SortingValue: sortingValue !== null ? sortingValue.value : '' }, () => {
      this.getFilteredShipmentList()
    })
  }

  getShipmentSearchParam = (searchBox: any) => {
    this.setState({ shipmentId: searchBox.target.value.toUpperCase() })
  }

  getFilteredShipmentList = () => {
    let filteredShipmentList = this.state.shipmentId !== '' ? this.props.shipments.filter((shipment: any) => shipment.id === this.state.shipmentId) : this.props.shipments.slice(20 * this.state.selectedPage - 20, 20 * this.state.selectedPage)
    if (filteredShipmentList.length > 0) {
      filteredShipmentList = filteredShipmentList.sort((shipment1: any, shipment2: any) => {
        if (this.state.SortingValue === constants.ASC_SORT_ORDER_USERID)
          return shipment1.userId.replace(constants.USER_INITIAL, '') - shipment2.userId.replace(constants.USER_INITIAL, '')
        else if (this.state.SortingValue === constants.DES_SORT_ORDER_USERID)
          return shipment2.userId.replace(constants.USER_INITIAL, '') - shipment1.userId.replace(constants.USER_INITIAL, '')
        else if (this.state.SortingValue === constants.DES_SORT_ORDER_SHIPMENTID)
          return shipment2.id.replace(constants.SHIPMENT_INITIAL, '') - shipment1.id.replace(constants.SHIPMENT_INITIAL, '')
        else if (this.state.SortingValue === constants.ASC_SORT_ORDER_SHIPMENTID)
          return shipment1.id.replace(constants.SHIPMENT_INITIAL, '') - shipment2.id.replace(constants.SHIPMENT_INITIAL, '')
        else
          return filteredShipmentList
      })
    }
    this.setState({ filteredShipmentList: filteredShipmentList })
  }

  render() {
    const {
      shipments,
      totalShipmentsCount
    } = this.props
    return (
      <div className='container-wrapper'>
        {this.state.shipmentDataFetchingDone ? <div className='container'>
          <Suspense fallback={<div />}>
            <ShipmentFiltersArea
              getShipmentSearchParam={this.getShipmentSearchParam}
              getFilteredShipmentList={this.getFilteredShipmentList}
            />
          </Suspense>
          {shipments && shipments.length > 0 ?
            <Suspense fallback={<Loading />}>
              <AvailableShipmentArea
                shipments={this.state.filteredShipmentList}
                getSortByFilterParams={this.getSortByFilterParams}
                totalShipmentsCount={totalShipmentsCount}
                getPageParams={this.getPageParams}
                currentPage={this.state.selectedPage}
                changePageNumber={this.changePageNumber}
                totalPageCount={Math.ceil(this.props.shipments.length / constants.SHIPMENT_PER_PAGE)}
                filteredShipmentList={this.state.filteredShipmentList}
              />
            </Suspense>
            :
            <Suspense fallback={<div />}><Loading /></Suspense>}
        </div> : <Suspense fallback={<div />}><Loading /></Suspense>}
      </div>
    )
  }
}

const mapStateToProps = (state: ShipmentHomeProps) => {
  return {
    shipments: state.Shipment.shipments,
    totalShipmentsCount: state.Shipment.totalShipmentsCount
  }
}

const mapDispatchToProps = (dispatch: any) => {
  return {
    shipmentsActions: bindActionCreators(shipmentsActions, dispatch)
  }
}

export default connect(mapStateToProps, mapDispatchToProps)(ShipmentHome)
