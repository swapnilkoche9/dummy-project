import { combineReducers } from 'redux'
import Shipment from './Shipment'

const Reducers = combineReducers({
  Shipment
})

export default Reducers
