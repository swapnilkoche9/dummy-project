import {
  FETCH_ALL_SHIPMENT_SUCCEEDED,
  FETCH_ALL_SHIPMENT_FAILED,
  UPDATE_SHIPMENT_NAME_SUCCEEDED
} from '../constants'
import { GenericAction } from '../utils/interface'
const initialState = {
  shipments: [],
  totalShipmentsCount: 0
}


function Shipments(state = initialState, action: GenericAction) {
  switch (action.type) {
    case FETCH_ALL_SHIPMENT_SUCCEEDED:

      return Object.assign({}, state, {
        shipments: action.payload,
        totalShipmentsCount: action.payload.length
      })

    case FETCH_ALL_SHIPMENT_FAILED:
      return Object.assign({}, state, {
        shipments: [],
        fetchingShipmentsError: action.payload.error.message
      })

    case UPDATE_SHIPMENT_NAME_SUCCEEDED:
    return Object.assign({}, state, {
      shipments: action.payload,
    })

    default:
      return state
  }
}

export default Shipments
