import React, { Component } from 'react'
import { Route, Switch } from 'react-router-dom'
import Header from './components/Header'
import Footer from './components/Footer'
import './styles/styles.scss'
import asyncComponent from './hoc/AsyncComponent';

const ShipmentHome = asyncComponent(() => {
  return import('./container/ShipmentHome');
})
const ShipmentDetails = asyncComponent(() => {
  return import('./container/ShipmentDetails');
})
const PageNotFound = asyncComponent(() => {
  return import('./components/PageNotFound');
})
class App extends Component {
  render () {
    return (
      <div className='App'>
        <Header/>
        <Switch>
          <Route exact path='/' component={ShipmentHome} />
          <Route exact path='/shipment/:shipmentId' component={ShipmentDetails} />
          <Route path='*' component={PageNotFound} />
        </Switch>
        <Footer/>
      </div>
    )
  }
}

export default App
