import { get, checkHttpStatus, parseJSON } from './fetch'

export const getShipmentApi = (filterParams = null) => {
  return get('shipments', filterParams)
    .then(checkHttpStatus)
    .then(parseJSON)
    .catch((err:string) => err)
}
