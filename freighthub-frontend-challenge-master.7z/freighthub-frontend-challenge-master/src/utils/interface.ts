export type shipmentsActions = {

    getAllShipments: Function,
    getShipmentsFailure: Function,
    getShipmentsSuccess: Function,
    updateShipmentName: Function,
}

export type Shipments = {
    shipments: Array<Shipment>,
    totalShipmentsCount: number,
    length: number,
    map: Function,
    filter: Function
}

export type Shipment = {
    name: string
    userId: string
    id: string
    mode: string
    destination: string
    origin: string
    status: string
    filter:Function
    length:number
    Shipment:any
}
export type ShipmentDetailsProps = {
    match: {
        isExact: boolean,
        params: any,
        path: string,
        url: string
    },
    Shipment: any
    shipmentsActions: shipmentsActions,
    shipments: any,
    
}
export type ShipmentDetailsState = {
    selectedShipment: any,
    isNameEditable:boolean,
    newShipmentName:string
}


export type ShipmentHomeProps = {
    shipments: any
    shipmentsActions: shipmentsActions,
    Shipment: any,
    totalShipmentsCount: number,

}
export type ShipmentHomeState = {
    shipmentId: string,
    SortingValue: String,
    filteredShipmentList: any,
    shipmentDataFetchingDone: boolean,
    selectedPage: number,
    totalPageCount:number
}

export type AvailableShipmentProps = {
    name: string
    userId: string
    id: string
    mode: string
    destination: string
    origin: string
    status: string
}

export type AvailableShipmentAreaProps = {
    shipments: Shipments
    totalShipmentsCount: number
    getSortByFilterParams: Function,
    getPageParams:Function,
    currentPage:number,
    changePageNumber:Function,
    totalPageCount:number,
    filteredShipmentList:Shipments
}
export type ButtonProps = {
    text: string,
    handleClick: any
}
export type ShipmentFiltersAreaProps = {
    getShipmentSearchParam: Function
    getFilteredShipmentList: Function
}

export type PaginationProps = {
    changePageNumber: Function,
    getPageParams: Function,
    currentPage: number,
    totalPageCount: number,
}

export type FilterObject = {
    label: String
    value: string
}
export type DropDownProps = {
    dropdownContent: any
    getFilterParams: any
    dropDownLabel: string
}
export type GenericAction = {
    type: string,
    payload: any
}